<?php
// Fungsi untuk mendapatkan base URL tanpa query string
function getBaseUrl() {
    // Deteksi otomatis protokol
    $isSecure = false;

    // Periksa variabel server untuk menentukan apakah HTTPS digunakan
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
        $isSecure = true;
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
        $isSecure = true;
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_SSL']) && $_SERVER['HTTP_X_FORWARDED_SSL'] === 'on') {
        $isSecure = true;
    } elseif (!empty($_SERVER['REQUEST_SCHEME']) && $_SERVER['REQUEST_SCHEME'] === 'https') {
        $isSecure = true;
    } elseif (isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] === '443') {
        $isSecure = true;
    }

    // Tentukan protokol berdasarkan deteksi
    $protocol = $isSecure ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'];

    // Mendapatkan direktori saat ini (misalnya, /news/)
    $directory = dirname($_SERVER['SCRIPT_NAME']);
    // Pastikan direktori tidak kosong dan tidak hanya "/"
    $directory = ($directory === '/' || empty($directory)) ? '' : $directory;

    // Bentuk base URL tanpa nama file (hanya direktori)
    return rtrim($protocol . "://" . $host . $directory, '/');
}

// Membaca keyword dari list.txt
$keywords = [];
$listFile = 'out.txt';

if (file_exists($listFile)) {
    $keywords = file($listFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if ($keywords === false) {
        $keywords = [];
    }
} else {
    // Jika file tidak ditemukan, gunakan keyword default
    $keywords = ['default-slug'];
}

// Filter keywords yang tidak valid
$validKeywords = [];
foreach ($keywords as $keyword) {
    $keyword = trim($keyword);
    if (!empty($keyword) && strlen($keyword) >= 2) {
        $validKeywords[] = $keyword;
    }
}

// Mendapatkan base URL
$baseUrl = getBaseUrl();

// Mendapatkan tanggal saat ini untuk lastmod
$currentDate = date('c'); // Format ISO 8601 (contoh: 2025-05-05T13:06:27+07:00)

// Konfigurasi untuk splitting
$urlsPerFile = 5000; // Jumlah URL per file sitemap
$totalKeywords = count($validKeywords);
$totalFiles = ceil($totalKeywords / $urlsPerFile);

// Fungsi untuk membuat file verifikasi Google
function createGoogleVerificationFile() {
    $filename = 'googlebceb8dd6aef76f28.html';
    $content = 'google-site-verification: googlebceb8dd6aef76f28.html';
    
    if (file_put_contents($filename, $content) === false) {
        return false;
    }
    return $filename;
}

// Fungsi untuk membuat sitemap files
function createSitemapFile($keywords, $baseUrl, $currentDate, $fileNumber) {
    $xmlContent = '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
    $xmlContent .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;

    foreach ($keywords as $keyword) {
        $encodedKeyword = urlencode($keyword);
        
        // Bentuk URL tanpa karakter escape tambahan
        $url = str_replace('\\', '', $baseUrl . '/?video=' . $encodedKeyword);
        
        $xmlContent .= '  <url>' . PHP_EOL;
        $xmlContent .= '    <loc>' . $url . '</loc>' . PHP_EOL;
        $xmlContent .= '    <lastmod>' . $currentDate . '</lastmod>' . PHP_EOL;
        $xmlContent .= '    <changefreq>daily</changefreq>' . PHP_EOL;
        $xmlContent .= '    <priority>0.8</priority>' . PHP_EOL;
        $xmlContent .= '  </url>' . PHP_EOL;
    }

    $xmlContent .= '</urlset>' . PHP_EOL;

    $filename = 'sitemap' . $fileNumber . '.xml';
    if (file_put_contents($filename, $xmlContent) === false) {
        return false;
    }
    return $filename;
}

// Membuat sitemap index
function createSitemapIndex($sitemapFiles, $baseUrl, $currentDate) {
    $xmlContent = '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
    $xmlContent .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . PHP_EOL;

    foreach ($sitemapFiles as $file) {
        // Bentuk URL tanpa karakter escape tambahan
        $url = str_replace('\\', '', $baseUrl . '/' . $file);
        
        $xmlContent .= '  <sitemap>' . PHP_EOL;
        $xmlContent .= '    <loc>' . $url . '</loc>' . PHP_EOL;
        $xmlContent .= '    <lastmod>' . $currentDate . '</lastmod>' . PHP_EOL;
        $xmlContent .= '  </sitemap>' . PHP_EOL;
    }

    $xmlContent .= '</sitemapindex>' . PHP_EOL;

    $filename = 'sitemap_index.xml';
    if (file_put_contents($filename, $xmlContent) === false) {
        return false;
    }
    return $filename;
}

// Buat file verifikasi Google
$verificationFile = createGoogleVerificationFile();
if ($verificationFile !== false) {
    echo "Successfully created Google verification file: $verificationFile" . PHP_EOL;
} else {
    echo "Failed to create Google verification file" . PHP_EOL;
}

// Buat sitemap files
$sitemapFiles = [];
$errors = [];

for ($i = 0; $i < $totalFiles; $i++) {
    $start = $i * $urlsPerFile;
    $keywordsChunk = array_slice($validKeywords, $start, $urlsPerFile);
    
    $filename = createSitemapFile($keywordsChunk, $baseUrl, $currentDate, $i + 1);
    if ($filename) {
        $sitemapFiles[] = $filename;
    } else {
        $errors[] = "Gagal membuat sitemap" . ($i + 1) . ".xml";
    }
}

// Buat sitemap index jika ada lebih dari satu sitemap file
if (count($sitemapFiles) > 0) {
    $indexFile = createSitemapIndex($sitemapFiles, $baseUrl, $currentDate);
    if (!$indexFile) {
        $errors[] = "Gagal membuat sitemap_index.xml";
    }
}

// Tampilkan hasil
if (empty($errors)) {
    echo "Sitemap berhasil dibuat:<br>";
    if (isset($indexFile)) {
        echo "- Sitemap Index: " . realpath($indexFile) . "<br>";
    }
    foreach ($sitemapFiles as $file) {
        echo "- " . $file . ": " . realpath($file) . "<br>";
    }
} else {
    echo "Terjadi kesalahan:<br>";
    foreach ($errors as $error) {
        echo "- " . $error . "<br>";
    }
}
?>